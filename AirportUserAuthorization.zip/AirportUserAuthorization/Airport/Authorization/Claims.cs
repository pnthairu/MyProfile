namespace Airport.Authorization
{
    public static class Claims
    {
        public const string IsBannedFromLounge = "IsBannedFromLounge";
        public const string FrequentFlyerClass = "FrequentFlyerClass";
        public const string FullName = "FullName";
        public const string BoardingPassNumber = "BoardingPassNumber";
    }
}