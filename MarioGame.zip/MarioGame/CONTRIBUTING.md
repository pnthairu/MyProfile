Hey there, you're welcome to contribute to this project.
Just fork the project, create pull request and I'll check it.
Thanks, 
Ronny.
