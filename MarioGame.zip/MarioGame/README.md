# Mario Objects

![](https://github.com/jazzyjester/Mario-Objects/blob/master/mario_level_1.png)
![](https://github.com/jazzyjester/Mario-Objects/blob/master/mario_level_2.png)
![](https://github.com/jazzyjester/Mario-Objects/blob/master/mario_level_3.png)

##Introduction
Mario Objects is a Mario game  + level editor created by me when I was at collage.
This was my first project I made in c# to learn the language.
I started it as little project to learn how to use bitmaps and surfaces in c# and 
because of my deep love with the mario game I decided to practice on mario sprites.

As time goes by I added more and more objects to the game , timers, mario phisics,
intersections with other objects and its became a really nice projects so in addition
I added to it a nice level editor to be able to create some type of levels.

Its not perfect and many parts of the game are not as they are supposed so be but as
a result I was very proud of it.

##Content

The solution created in Visual Studio 2010 and contains 4 projects
- **MarioObjects** - Main Game Project.
- **MarioLevel Editor** - Level Editor Project.
- **Mario Rectangle** - Simple tests project.
- **Mario Test** - Simple Unit test project.

## Level Editor

The level editor creates XML file that later will be loaded to the game and create all the objects for the game.
All the objects that are available are on the left panel.
Click on the same object will bring the properties screen if available.
I know the UX is very bad, but thats what I thought on that time.

![](https://github.com/jazzyjester/Mario-Objects/blob/master/mario3.png)


## Contact
Write to me if you like the game  : jazzyjester@gmail.com


